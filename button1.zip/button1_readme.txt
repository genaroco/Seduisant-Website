We hope you like this button! You may use it free of charge on any website, commercial or non-commercial. 
It's great if you want to link back to use (http://www.doubleplus.com) but you don't have to if you don't
want.

If you want to make a similar button, please see this tutorial:
http://www.flash-game-design.com/tutorials/smart-home-button.html

Thanks!
Susan Petracco
www.doubleplus.com
